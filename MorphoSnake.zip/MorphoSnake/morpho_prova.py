#!/usr/bin/env python3 
#
# MorphoSnake - Python Morphometry program for 2D shapes
#
# Fredrik Jansson, Pirom Konglerd, Catherine Reeb 2014-2017
# Released under the GNU General Public License v3.0.
# https://github.com/fjansson/MorphoSnake
#
# written for Python3
'''
import mahotas as mh
import matplotlib as mpl
import matplotlib.colors
import matplotlib.pyplot as plt
'''
import numpy as np
from skimage.morphology import skeletonize,thin
import networkx as nx
import json
import sys
import os.path
import pickle
import cv2

path = os.path.abspath(os.path.dirname(__file__)) #salva nella variabile path il percorso globale della cartella in cui si trova il file .py in esecuzione
os.chdir(path)  #cambio della cartella attuale nella cartella in cui si trova il file .py

img = cv2.imread(path+r'\img\erosion.jpg',0)
print(img)
thresh, img = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY)
print(img)
print('Thinning...')
# skeletonization from scikit image.
# Zhang-Suen algorithm (apparently with staircase removal)

#img= img.astype(np.uint8)
skel = skeletonize(img//255)*255
#skel = skel.astype(np.uint8)
#skel = np.asarray(skel, dtype="uint8")
print(skel)
cv2.imwrite(path+r'\img\provaskel.jpg',skel)

'''
# Try mahotas skeletonization. Makes many spikes.
# works better after mh.close(), but still splits many tips in two.
# Also gives staircases in the skeleton.
#skel = mh.thin(img)  
#skel = morphology.skeletonize(skel)  # one pass of the other skeletonization to remove staircases



################

# find terminals and junctions. t and j are in the format [(x1, y1), (x2, y2), ...]
print('Features...')
t, j = terminals(skel) 

if root == None:
    # unpack the tuples to separate lists of x:s and y:s, for plotting and root selection
    tx = [x[0] for x in t]
    #ty = [x[1] for x in t]

    # find the index of the left-most terminal. Use that as the root, for now.
    iroot = tx.index(min(tx))

    # find the lowest node, to use as root
    root = t[iroot]
else:
    if root not in t+j:
        newroot = findClosest(t+j, root)
        print('Moving the root to a node in the tree. New root is', str(newroot), 'old root was', str(root), 'distance', dist(newroot, root))     
        root = newroot


print('Plotting')
# create a copy of the boolean skeleton for further use
skel2 = skel

# make the skeleton image's background transparent
skel    = np.ma.masked_where(skel==0, skel)
#visited = np.ma.masked_where (visited==0, visited)

fig = plt.figure()

superposed = False

# update measures that depend on graph structure or root placement
def updateMeasures(G, root):
    print('  Strahler order...')
    StrahlerOrder(G, root)
    print('  apical distances...')
    measureApicalDist(G)
    print('  branch angles...')
    measureAngles(G)
    
def buildGraph(img, skel):
    print('Building tree...')
    G = nx.Graph()
    visited = np.zeros_like(skel) # a new array of zeros, same dimensions as skel
    dmap = mh.distance(img)
    
    print('  constructing tree...')
    buildTree(skel, visited, dmap, root, j, t, G)

    # measure node diameters
    measureDia(G, dmap)

    # automatically remove bad nodes and branches, e.g. too small ones
    removed = cleanup(G, root)
    # show (automatically) removed nodes
    for x,y in removed:
        plt.gca().add_patch(plt.Circle((x,y), radius=4, alpha=.4))
    updateMeasures(G, root)

    # measure node diameters 2
    measureLeafWidth(contour,G,root)
    
    initializeColorNode(G)
    print('Done.')

    return G

def loopSolution(G,skel,img):
    print("Image with Loops detected, attempting automatic unLooping")
    alpha = np.pi - findAngleMoy(G)
    img,cutPoints = finalStrat(img,contours,alpha,d_alpha,root,d_pixels)
    print('Thinning...')
    skel = morphology.skeletonize(img)
    print('Features...')
    t, j = terminals(skel)
    skel2 = skel
    skel  = np.ma.masked_where(skel==0, skel)
    return img,skel,skel2,t,j,cutPoints
        

contour = findContour(img)

if(len(contours)>2):
    superposed = True
    print("image with loops detected, useless to use an older graph, constructing the graph")
    G = buildGraph(img, skel)
    if(len(contours)>2):
        img,skel,skel2, t,j, cutPoints = loopSolution(G,skel,img)
        G = buildGraph(img, skel)
        contour = findContour(img)
        markCutPoints(G,cutPoints,20)
else:
    # read in the graph from a previous run, if it exists
    try:
        G=nx.read_gpickle(path_basename+'_graph.pkl')
        print('Loaded graph from ' + path_basename + '_graph.pkl')
        print('Graphs created by an older version of this software wont load, please delete ' + path_basename + '_graph.pkl file and retry in case of error.')
        
    except:
        # could not read the graph. Constructing it now
        G = buildGraph(img, skel)
    
        
# Plot images. Inversion here is just for nicer coloring
# interpolation=nearest is to turn smoothing off.

width = skel.shape[1]
height= skel.shape[0]

plt.axis((0,width,height,0))
plt.imshow(~img, cmap=leaf_colors, interpolation="nearest")
plt.imshow(skel, cmap=skel_colors,  interpolation="nearest")


# handles to plot elements
nodes = None
edges = None
node_labels = None
edge_labels = None

rad=[]
plot_graph(G)

# semi-transparent circles on the nodes

Cercle = {}

for p,r in zip(G, rad):
	Cercle[p] = plt.Circle(p, radius=r, alpha=terminal_disk_alpha, color=terminal_disk_color)
	plt.gca().add_patch(Cercle[p])

root_patch = plt.Circle(root, radius=40, alpha=root_disk_alpha, color=root_disk_color)
plt.gca().add_patch(root_patch)

select_patch = plt.Circle(root, radius=40, alpha=select_disk_alpha, color=select_disk_color)
plt.gca().add_patch(select_patch)


def updateCircles(G,C):
   for p in C:
       if p not in G:
           C[p].set_visible(False)
       else:
           C[p].set_visible(False)
           # REVIEW DIA2 TO DIA
           C[p] = plt.Circle(p, radius=G.node[p]['dia_2']/2, alpha=terminal_disk_alpha, color=terminal_disk_color)
           plt.gca().add_patch(C[p])

updateCircles(G,Cercle)
            
moyAngle,moyAngle_e = MoyAngleStrahler(G)

def setRoot(root):
    root_patch.center = root;

    # save the new root in database
    # convert to int from numpy type, for JSON to work later
    leafData['root'] = (int(root[0]), int(root[1]))
    
	
# a function called when the user clicks a node    
def onpick(event):
    global select
    # make the clicked node the new selected node
   
    # for some reason it's difficult to get the coordinates of the clicked node
    # so we use mouse coordinates and search for the closest node.
    select = findClosest(list(G.nodes()), (event.mouseevent.xdata, event.mouseevent.ydata))
    select_patch.center = select
    plot_graph(G)
    fig.canvas.draw()

undo_stack = []

# a function called on keypress events
def keypress(event):
    global nodes, edges, node_labels, G, root, select
    print('press', event.key)
    sys.stdout.flush()

    if event.key=='x': # delete closest branch
        e = findClosestEdge(G, (event.xdata, event.ydata))
        undo_stack.append((G.copy(), root,Cercle))
        G.remove_edge(*e)

        updateMeasures(G, root)
        plot_graph(G)        
        fig.canvas.draw()

    if event.key=='u': # undo
        if len(undo_stack) > 0:
            print('Undo')
            G,root,C = undo_stack.pop()
            setRoot(root)
            updateMeasures(G, root)
            updateCircles(G,C)
            plot_graph(G)        
            fig.canvas.draw()
        else:
            print('No further undo')

    if event.key=='r': #re-build the graph from skeleton
        print('Rebuilding tree')
        undo_stack.append((G.copy(), root,Cercle))
        G = buildGraph(img, skel)
        plot_graph(G)
        updateCircles(G,Cercle)
        fig.canvas.draw()

    if event.key == 'n': #add node
        p =   findClosestSkel(skel2,(event.xdata,event.ydata))
        print('closest node is (%5.1f, %5.1f)'%p)
        undo_stack.append((G.copy(),root,Cercle))
        print('adding node');
        try:
            addNodeSkel(G,p,skel2,j,t,dmap)
        except:
            print('  distance transform...')
            dmap = mh.distance(img)
            addNodeSkel(G,p,skel2,j,t,dmap)

        Cercle[p] = plt.Circle(p, radius=(G.node[p]['dia']/2), alpha=terminal_disk_alpha, color=terminal_disk_color)
        updateCircles(G,Cercle)
        updateMeasures(G, root)
        report(G)
        plot_graph(G)        
        fig.canvas.draw()


        
    if select == None:    # verify the selection
        print('No active selection, please select a node')
        return
    
    if event.key=='t': # change the root
        undo_stack.append((G.copy(), root, Cercle))
        root = select
        print('New root: ' + str(root))
        setRoot(root)
        updateMeasures(G, root)
        report(G)
    
        plot_graph(G)        
        fig.canvas.draw()
        
    
    if event.key=='d': # delete closest node
        p = select
        if p == root:
            print('Cannot remove the root.')
            return
        undo_stack.append((G.copy(), root, Cercle))
        deleteNode(G,p)
        Cercle[p].remove()
        #report(G)
        
        updateMeasures(G, root)
        plot_graph(G)        
        fig.canvas.draw()
        

    if event.key=='a': #marking of fertile nodes
        p = select
        print('this node is now fertile')
        undo_stack.append((G.copy(),root,Cercle))
        G.node[p]['node_color'] = node_color_fertile
        G.node[p]['fertile'] = True
        G[p][G.node[p]['parent']]['fertile'] = True
        report(G)
        plot_graph(G)
        fig.canvas.draw()


    if event.key == 'alt+e': #hide any latest selection
        print('hide caracteristics')
        undo_stack.append((G.copy(),root,Cercle))
        for p in G:
            if G.node[p]['node_color'] != node_color:
                G.node[p]['node_color'] = node_color
                plot_graph(G)
                fig.canvas.draw()
        report(G)


    if event.key == 'b': # diameter modification
        p = select
        print('closest node is (%5.1f, %5.1f)'%p)
        undo_stack.append((G.copy(),root,Cercle))
        G.node[p]['dia_2'] = 2*dist(p,(event.xdata,event.ydata))
        updateMeasures(G, root)
        Cercle[p].remove()
        Cercle[p] = plt.Circle(p,radius=G.node[p]['dia_2']/2,alpha=terminal_disk_alpha,color=terminal_disk_color)
        plt.gca().add_patch(Cercle[p])
        plot_graph(G)        
        fig.canvas.draw()   

        
# register the event callback functions
fig.canvas.mpl_connect('pick_event', onpick)
fig.canvas.mpl_connect('key_press_event', keypress)

# plot disks for the apical distance, just for testing
# for n in G:
#    if G.node[n]['level'] == 1:
#        r = G.node[n]['apicaldist']
#        plt.gca().add_patch(plt.Circle(n, radius=r, alpha=.4))

        
report(G)
if superposed:
    print("WARNING, the presented image has superposed parts, the proposed solution is experimental, if you are not satisfied with the proposed cuts in the image, it is suggested to manually cut the problematic sections and try again.")
plt.tight_layout()

# show the plot - program pauses here for as long as the window is open
plt.show()

saveTreeText(G, path_basename+'_branches.txt', path_basename+'_nodes.txt');
nx.write_gpickle(G, path_basename+'_graph.pkl')

def saveReport(reportFile, report_text, header_text):
    # if the file does not exist already, write the header
    present = os.path.isfile(reportFile)

    print('Saving leaf report in file ' + reportFile)
    try:
        f = open(reportFile, 'at')
        if not present:
            f.write(header_text+'\n'+'\n')
        f.write(report_text+'\n'+'\n')
    except:
        print('Error when saving the report')

report_text,header_text = report(G)
reportFile = 'results.txt'
saveReport(reportFile, report_text, header_text)

print('Saving the database...')
# save the leaf data base
of = open(leavesFile, "wt")
json.dump(leaves, of, sort_keys=True, indent=2, separators=(',', ': '))
print('done.')
'''
